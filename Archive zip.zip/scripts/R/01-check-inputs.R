# Run from the repository root. Optional arguments: INPUT_DIRECTORY OUTPUT_DIRECTORY.
suppressPackageStartupMessages(library(tidyverse))
args <- commandArgs(trailingOnly = TRUE)
input_dir <- if (length(args) >= 1) args[1] else "data/example"
output_dir <- if (length(args) >= 2) args[2] else "results"
check <- function(ok, message) { if (!isTRUE(ok)) stop(message, call. = FALSE) }
read_input <- function(name) {
  path <- file.path(input_dir, name)
  check(file.exists(path), paste("Missing input:", path))
  read_tsv(path, name_repair = "minimal", show_col_types = FALSE)
}
x <- read_input("feature-counts.tsv")
m <- read_input("sample-metadata.tsv")
t <- read_input("taxonomy.tsv")
check(ncol(x) >= 2 && names(x)[1] == "feature_id", "Counts need feature_id followed by sample columns.")
check(all(c("sample_id", "group") %in% names(m)), "Metadata need sample_id and group.")
check(all(c("feature_id", "taxon") %in% names(t)), "Taxonomy needs feature_id and taxon.")
check(nrow(x) > 0 && nrow(m) > 0, "Input tables must contain rows.")
check(!anyDuplicated(names(x)) && !anyDuplicated(names(m)) && !anyDuplicated(names(t)), "Duplicate column names.")
valid_ids <- function(v) !anyNA(v) && all(nzchar(trimws(as.character(v)))) && !anyDuplicated(v)
check(valid_ids(x$feature_id), "Feature IDs must be unique and nonblank.")
check(valid_ids(m$sample_id), "Sample IDs must be unique and nonblank.")
check(valid_ids(t$feature_id), "Taxonomy feature IDs must be unique and nonblank.")
check(!anyNA(m$group) && all(nzchar(trimws(as.character(m$group)))), "Groups must be nonblank.")
check(!anyNA(t$taxon) && all(nzchar(trimws(as.character(t$taxon)))), "Taxon labels must be nonblank.")
check(setequal(names(x)[-1], m$sample_id), "Count sample IDs must match metadata exactly.")
check(setequal(x$feature_id, t$feature_id), "Count feature IDs must match taxonomy exactly.")
check(all(vapply(x[-1], is.numeric, logical(1))), "Counts must be numeric.")
a <- as.matrix(x[-1])
check(!anyNA(a) && all(is.finite(a)) && all(a >= 0) && all(a == floor(a)), "Counts must be finite nonnegative integers without missing values.")
check(all(colSums(a) > 0), "Every sample must have a positive count total.")
check(n_distinct(m$group) >= 2, "Community comparison needs at least two groups.")
if (any(rowSums(a) == 0)) warning("All-zero features are present; document any filtering.")
if (any(table(m$group) < 3)) warning("Some groups have fewer than three samples; summaries are limited.")
dir.create(file.path(output_dir, "tables"), recursive = TRUE, showWarnings = FALSE)
write_tsv(tibble(check = c("samples", "features", "groups", "validation"),
                 value = c(nrow(m), nrow(x), n_distinct(m$group), "PASS")),
          file.path(output_dir, "tables", "input-checks.tsv"))
message("Input checks passed.")
